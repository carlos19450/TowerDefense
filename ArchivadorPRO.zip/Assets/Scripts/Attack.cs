using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    private Enemy enemy;
    public GameObject bulletPrefab;
    public float rotationSpeed = 35;

    void OnTriggerEnter(Collider co)
    {
        if (co.GetComponent<Enemy>()) {
            GameObject g = (GameObject)Instantiate(bulletPrefab, transform.position, Quaternion.identity);
            g.GetComponent<Bullet>().target = co.transform;
        }
    }
}
