using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    private TextMesh tm;
    // Start is called before the first frame update
    void Start()
    {
        tm = GetComponent<TextMesh>();
        GameObject egg = GameObject.Find("Egg");
        if (egg)
            GetComponent<NavMeshAgent>().destination = egg.transform.position;
    }
    void OnTriggerEnter(Collider col) {
        // If castle then deal Damage
        if (col.name == "Egg") {
            col.GetComponentInChildren<HealthBar>().decrease();
            Destroy(gameObject);
        }

        if (tm.text.Length <= 0)
        {
            Destroy(gameObject);
        }
    }
}
