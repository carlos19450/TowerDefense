using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject enemyPrefab;
    public float nextSpawn = 3;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnNext", nextSpawn, nextSpawn);
    }
    void SpawnNext() {
        Instantiate(enemyPrefab, transform.position, Quaternion.identity);
    }
}
